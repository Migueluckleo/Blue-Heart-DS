# Contratos y enmiendas

Registro inicial vacío. Registrar alcance, fuente, versión y evidencia según [P05](../protocols/05-SELF-DOCUMENTATION-AND-TRACEABILITY.md).

## FOUNDATIONS-BLUEHEART-VARIABLES-001

[Contrato v0.1.2](../specs/foundations/blueheart-variables.contract.v0.1.2.md) · DELEGATED_FOR_BUILD · [QA de implementación](../qa/implementations/blueheart-variables.v0.1.2.review.md). Los candidatos previos y sus datos se conservan en `output/variables-proposal/`.

## BUTTON-001 y LOADER-001

[Buttons v1.0.0](../specs/components/buttons.contract.v1.0.0.md) y [Loader v1.0.0](../specs/components/loader.contract.v1.0.0.md) · DELEGATED_FOR_BUILD. Proyección de la raíz vigente y QA de [Figma y web](../qa/implementations/buttons-loader.v1.0.0.review.md).

Las guías de [Buttons](../specs/components/buttons.usage.amendment.v1.0.1.md) y [Loader](../specs/components/loader.usage.amendment.v1.0.1.md) amplían semántica y casos v1.0.1. La implementación queda en v1.0.0.

[Sidebar v1.0.1](../specs/components/sidebar.secondary-control.amendment.v1.0.1.md) · DELEGATED_FOR_BUILD. Delega Secondary para Expand y Collapse en Figma y web. El Ghost de la raíz queda registrado como antecedente.

[Avatar](../specs/components/avatar.contract.v1.0.0.md) y [Avatar group](../specs/components/avatar-group.contract.v1.0.0.md) · DELEGATED_FOR_BUILD con QA documental. Avatar group delega un Slot Avatars. La fotografía tiene procedencia y bloqueo de implementación nativa registrado.

[Company selector](../specs/components/company-selector.contract.v1.0.0.md), [User selector](../specs/components/user-selector.contract.v1.0.0.md), [Header actions](../specs/components/header-actions.contract.v1.0.0.md) y [Header](../specs/components/header.contract.v1.0.0.md) · DELEGATED_FOR_BUILD con QA documental. Header compone los tres maestros, Badge y el asset oficial de Contabilidad.

[Input](../specs/components/input.contract.v1.0.0.md) · DELEGATED_FOR_BUILD con QA documental. Delega dos sets de 21 variantes, Badge subtle/small y los estilos de foco.

[Section Header](../specs/components/section-header.contract.v1.0.0.md) · DELEGATED_FOR_BUILD con QA documental. Delega tres Slots y dependencias oficiales de navegación y acciones.

[App Shell](../specs/components/app-shell.contract.v1.0.0.md) · DELEGATED_FOR_BUILD con QA documental. Delega cuatro variantes de escritorio y un Body compartido.
