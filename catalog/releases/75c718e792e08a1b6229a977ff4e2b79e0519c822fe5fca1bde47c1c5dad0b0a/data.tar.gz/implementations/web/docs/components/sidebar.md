# Sidebar · React / TypeScript

Documento técnico generado por `pnpm ds:generate`. Editar la API en código, el ejemplo ejecutable o las notas de `components.registry.json`, y regenerar. No es otra aprobación del contrato visual.

Familia `SIDEBAR-001` · API local 0.1.0 · categoría navegación.

## Guía semántica normativa

Fuente: [guía del contrato](../../../../specs/components/sidebar.contract.v1.0.0.md#guía-semántica-normativa).

Usa Sidebar para navegación lateral persistente. Conserva un control accesible para expandir o contraer. El anfitrión define el contenido principal y las opciones inferiores de cada presentación, la altura disponible y la ruta actual. Mantén la ayuda en una ubicación coherente y asigna nombres accesibles a todos los controles iconográficos.

| Situación | Haz | Evita |
|---|---|---|
| Navegación contraída | Conserva nombre por destino y ofrece «Expandir navegación». | Depender de que la persona reconozca cada icono. |
| Menú expandido | Agrupa destinos y ayuda en sus Slots. | Convertir el número de la muestra en un límite. |
| Cambiar presentación | Mantén explícitas las listas que corresponden a cada presentación. | Prometer que el contenido personalizado se sincroniza automáticamente. |

El anfitrión resuelve rutas, permisos, scroll y adaptación móvil. [Carbon UI shell](https://www.carbondesignsystem.com/building-blocks/core/components/ui-shell-left-panel/guidelines) · [W3C Disclosure Navigation](https://www.w3.org/WAI/ARIA/apg/patterns/disclosure/examples/disclosure-navigation/)

## Uso sin backend

Expande y contrae con teclado. Cada presentación tiene contenido propio.

```tsx
'use client';

import { useEffect, useRef, useState } from 'react';
import { QuestionIcon } from '@phosphor-icons/react/dist/csr/Question';
import { CheckCircleIcon } from '@phosphor-icons/react/dist/csr/CheckCircle';
import { Button, buttonSizes, buttonVariants, Dot, Radio, RadioGroup, Toggle, Tooltip, LinearProgress, Checkbox, FileUpload, Search, BreadcrumbItem, Breadcrumb, MenuItem, TopBar, IconButton, Sidebar, Badge, type CheckboxSelection, type FileUploadState, Loader, loaderColors, loaderSizes, type ButtonState } from '@/index';

const states: ButtonState[] = ['default', 'hover', 'pressed', 'focus', 'loading', 'disabled'];

export function SidebarExample() {
  const [collapsed, setCollapsed] = useState(true);
  return <div className="my-4">
    <Sidebar label="Navegación lateral de muestra" collapsed={collapsed} onCollapsedChange={setCollapsed} className="h-72"
      collapsedMenuItems={<MenuItem label="Inicio" href="#demo-sidebar-target" current/>}
      collapsedLowerOptions={<MenuItem label="Ayuda" href="#demo-sidebar-target" active={false}
        fillIcon={QuestionIcon} lightIcon={QuestionIcon}/>}
      expandedMenuItems={<>
        <MenuItem label="Inicio" type="expanded" href="#demo-sidebar-target" current showRightIcon={false}/>
        <MenuItem label="Comprobantes" type="expanded" href="#demo-sidebar-target" active={false} showRightIcon={false}/>
      </>}
      expandedLowerOptions={<MenuItem label="Ayuda" type="expanded" href="#demo-sidebar-target" active={false}
        fillIcon={QuestionIcon} lightIcon={QuestionIcon} showRightIcon={false}/>}/>
    <span id="demo-sidebar-target" className="sr-only">Destino de muestra</span>
  </div>;
}
```

Ejemplo compilado en [examples.tsx](../../src/examples.tsx). Usa React state en memoria; recargar restaura la muestra. No hay endpoint, credencial ni persistencia implícita.

## API tipada

Importar desde [src/index.ts](../../src/index.ts), con `@/index` dentro del catálogo. Código propietario: [sidebar.tsx](../../src/components/sidebar.tsx). Los atributos HTML heredados mantienen los tipos de React; callbacks y datos controlados pertenecen a la pantalla.

```tsx
export interface SidebarProps {
  label: string;
  collapsed: boolean;
  onCollapsedChange: (collapsed: boolean) => void;
  collapsedMenuItems?: ReactNode;
  collapsedLowerOptions?: ReactNode;
  expandedMenuItems?: ReactNode;
  expandedLowerOptions?: ReactNode;
  className?: string;
}
```

## Defaults y eventos

Las firmas siguientes se extraen de las funciones, incluidos sus valores por defecto. Una prop sin asignación `=` es obligatoria o permanece undefined según su tipo; no se rellena con reglas de negocio.

```tsx
Sidebar: {label, collapsed, onCollapsedChange, collapsedMenuItems, collapsedLowerOptions,
  expandedMenuItems, expandedLowerOptions, className}: SidebarProps
```

Props `on…` son callbacks locales. No atribuyen autorización, carga, guardado ni resultados de negocio.

## Composición y Slots

P-SLOTS: **REQUIRED**. Cuatro Slots independientes permiten editar ambas presentaciones. ReactNode/listas tipadas son la traducción web de las regiones, no evidencia de Slots Figma. El anfitrión conserva el orden y los IDs de listas; las cantidades de las demos no son límites de producto.

## Estilos y Next.js

Importar [styles.css](../../src/styles.css) desde el layout. Consultar el manifiesto generado y los contratos vigentes para roles, modos y aliases.

Los ejemplos que usan estado/eventos requieren `'use client'`. Los datos serializables pueden venir de un Server Component; crear callbacks en una frontera cliente. No enviar funciones desde el servidor. No se requiere backend para el catálogo ni para componer con fixtures.

## Fuentes y límites

- [sidebar.contract.v1.0.0.md](../../../../specs/components/sidebar.contract.v1.0.0.md) · SHA-256 `0cfcf88001c7bbba68ad8011197bc3ff049e8dad5ab320dbfa5e149a68cf57f0`.

Las enmiendas sustituyen solo su alcance explícito. Los estados de aprobación, auditoría y excepciones visuales permanecen en esas fuentes. La API web inicial no certifica identidad pixel a pixel ni conformidad WCAG completa.

## Verificación

`pnpm verify` comprueba generación/cobertura, TypeScript, pruebas y build estático. `pnpm test:browser` valida los recorridos locales. [Evidencia de QA](../../../../qa/implementations/sidebar-chain.v1.0.0.review.md) identifica alcance, resultados y límites; una demo visible por sí sola no es un PASS visual.
