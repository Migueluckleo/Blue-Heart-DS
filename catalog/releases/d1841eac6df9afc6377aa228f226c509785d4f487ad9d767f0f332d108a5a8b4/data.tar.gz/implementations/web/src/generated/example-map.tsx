'use client';
import * as Examples from '../examples';
import type { ComponentType } from 'react';
export const examples: Record<string, ComponentType> = {
  "breadcrumb": Examples.BreadcrumbExample,
  "breadcrumb-item": Examples.BreadcrumbItemExample,
  "buttons": Examples.ButtonsExample,
  "checkbox": Examples.CheckboxExample,
  "dot": Examples.DotExample,
  "file-upload": Examples.FileUploadExample,
  "linear-progress": Examples.LinearProgressExample,
  "loader": Examples.LoaderExample,
  "radio": Examples.RadioExample,
  "radio-group": Examples.RadioGroupExample,
  "search": Examples.SearchExample,
  "toggle": Examples.ToggleExample,
  "tooltip": Examples.TooltipExample,
};
