# Inventario raíz de BlueHeart

La [captura reconciliada](../sources/figma-snapshots/root-families-2026-11-11/inventory.json) enumera 29 páginas y conserva IDs, keys, padres, variantes y aristas observadas por maestro. 27 páginas contienen maestros. Se localizaron 53 principales/sets públicos, 12 auxiliares de implementación y un set de demostración de Tooltip. Los 66 principales/sets suman 863 variantes o componentes individuales. Excluir el demo host de 12 variantes deja 65 maestros/sets en alcance y 851 variantes o individuales.

El demo host de Tooltip se excluye por su Description explícita. Las muestras de instancia y notas se registran como hijos de página fuente, fuera del inventario de maestros. Tab y Tabs aparecen dentro de frames en la raíz, pero sus identidades y dependencias acreditan que son maestros del sistema. El maestro de destino organiza sus definiciones directamente bajo la página oficial.

La captura registra dependencias locales y remotas. Dot precede a Avatar, Icon Buttons, Tabs y Floating Actions. Radio precede a Radio group. Tooltip precede a Menu item. Header, Sidebar y Section Header preceden a App Shell. Una referencia remota requiere comprobar identidad y acceso antes de construir sus consumidores.

El estado por maestro se actualiza en la evidencia de cada lote. INVENTORIED acredita lectura, sin atribuir QA o construcción.

## Estado del destino y continuidad

El [registro por maestro](root-families-status-2026-11-11.json) reconcilia los 66 IDs de fuente con el destino y las actas de QA. Se comprobaron 26 maestros/sets con 470 variantes. Quedan 39 maestros/sets oficiales con 381 variantes o individuales en estado INVENTORIED. El demo host de Tooltip conserva EXCLUDED_DEMO.

El corte anterior incorporó Dot, Toggle, Radio, Radio group y Tooltip. Los destinos son `32:33`, `32:97`, `32:142`, `35:108` y `38:22`. Las páginas oficiales se conservan sin exhibidores ni notas. Radio group prueba un único Options nativo reutilizando Radio. Las cinco familias están en el catálogo web con React/TypeScript, Tailwind, Next y QA. El inventario histórico `initialState` preserva el momento de captura y el registro por maestro contiene el avance verificado.

Este corte incorpora Search, Breadcrumb item y Breadcrumb. Breadcrumb reutiliza sus eslabones expuestos y desbloquea Section Header junto con las demás dependencias pendientes.

También se cerró Linear Progress Bar en tres tamaños y su auxiliar, File Upload y Checkbox. File Upload reutiliza Linear Progress Bar/large y Button secondary en Figma y React. Las tres familias tienen fichas, ejemplos Next y QA.

Para reanudar desde este corte, abrir los registros INVENTORIED y sus aristas de dependencias. Tooltip público `708:157` quedó verificado y desbloquea Menu item. Primera dependencia pendiente propuesta, Menu item `748:40`, desbloquea Sidebar, Top bar y su auxiliar de ayuda. Para Menu item cotejar Union VECTOR, el degradado con dos variables y efectos BETA, swaps Fill/Light y Tooltip right/center/simple. Las variantes oficiales de HouseLine y CaretDown ya están comprobadas en la captura Phosphor. Si la API de estilos retrasa ese lote, avanzar Text Area `661:169` o Icon Buttons usando Dot validado. Section Header conserva pendientes sus demás dependencias. Dot ya desbloquea Avatar, Icon Buttons, Tabs y Floating Actions. Resolver cada key de icono o marca remota en su biblioteca antes de usarla y documentar los accesos que falten. Revisar Options de Dropdown y las demás listas variables mediante P-SLOTS antes de elegir mecanismo. Conservar los resultados anteriores y continuar por dependencias hasta App Shell. El criterio por maestro es contrato, QA documental, Figma nativo, lectura independiente, P07 con prueba web, y cierre común de Graphify y las dos skills.
