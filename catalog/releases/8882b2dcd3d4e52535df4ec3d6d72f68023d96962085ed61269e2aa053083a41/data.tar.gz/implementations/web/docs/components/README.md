# Componentes web

Índice generado. Cada ficha contiene API, ejemplo ejecutable, Slots, fuentes y límites.

- [Buttons](buttons.md) · BUTTON-001
- [Dot](dot.md) · DOT-001
- [Loader](loader.md) · LOADER-001
- [Radio](radio.md) · RADIO-001
- [Radio group](radio-group.md) · RADIO-GROUP-001
- [Toggle](toggle.md) · TOGGLE-001
- [Tooltip](tooltip.md) · TOOLTIP-001
