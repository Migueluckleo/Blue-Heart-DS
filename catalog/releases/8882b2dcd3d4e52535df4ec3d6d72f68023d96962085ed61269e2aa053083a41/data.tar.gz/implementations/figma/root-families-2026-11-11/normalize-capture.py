"""Resolve a native source capture against the previously verified target variable map."""
import hashlib
import json
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[3]
slug, source_version, expected_count = sys.argv[1:]
source = root / 'sources/figma-snapshots/root-families-2026-11-11'
parts = sorted(source.glob(f'{slug}-*.detail.json'), key=lambda path: int(path.name.split('-')[-1].split('.')[0]))
items = [json.loads(path.read_text()) for path in parts]
norm = source / f'{slug}.{source_version}.md.txt'
map_path = root / 'implementations/figma/variables-2026-11-11/id-map.json'
names = {entry['sourceId']: entry for entry in json.loads(map_path.read_text())['variables']}
manifest_path = root / 'implementations/web/src/generated/tokens.manifest.json'
manifest = {entry['name']: entry for entry in json.loads(manifest_path.read_text())['tokens']}
tokens = {}

def bindings(node):
    mapped = {}
    for field, alias in node.get('boundVariables', {}).items():
        if isinstance(alias, list):
            if len(alias) != 1:
                raise ValueError(f'Unsupported multiple aliases on {field}')
            alias = alias[0]
        vid = alias['id']
        target = names[vid]
        name = target['targetPath']
        kind = 'STRING' if field in ('fontFamily', 'fontStyle') else 'COLOR' if field in ('fills', 'strokes') else 'FLOAT'
        tokens[vid] = dict(name=name, targetId=target['targetId'], css=manifest[name]['css'], type=kind)
        mapped[field] = vid
    return mapped

def normalize(node):
    scalar = set(('id name type x y width height visible layoutMode layoutPositioning layoutSizingHorizontal '
                  'layoutSizingVertical primaryAxisSizingMode counterAxisSizingMode primaryAxisAlignItems '
                  'counterAxisAlignItems paddingTop paddingRight paddingBottom paddingLeft itemSpacing minWidth '
                  'maxWidth minHeight maxHeight strokesIncludedInLayout clipsContent cornerRadius strokeWeight '
                  'strokeAlign rotation constraints fontName characters fontSize lineHeight letterSpacing textDecoration '
                  'textAlignHorizontal textAlignVertical textAutoResize textStyleId effectStyleId vectorPaths '
                  'main instanceProperties reactions').split())
    clean = {key: value for key, value in node.items() if key in scalar}
    for field in ('fills', 'strokes'):
        clean[field] = [{key: value for key, value in paint.items()
                         if key in ('type', 'color', 'opacity', 'visible', 'blendMode')}
                        for paint in node.get(field, [])]
    clean['b'] = bindings(node)
    if node.get('componentPropertyReferences'):
        clean['refs'] = node['componentPropertyReferences']
    if 'children' in node:
        clean['children'] = [normalize(child) for child in node['children']]
    return clean

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

variants = [normalize(variant) for item in items for variant in item['variants']]
assert len(variants) == int(expected_count) and len({variant['id'] for variant in variants}) == int(expected_count)
identity = items[0]
assert all(item['setId'] == identity['setId'] and item['properties'] == identity['properties'] for item in items)
styles = {
    key: {**{field: val for field, val in style.items() if field != 'boundVariables'}, 'b': bindings(style)}
    for item in items for key, style in item['styles'].items()
}
effects = {key: val for item in items for key, val in item.get('effectStyles', {}).items()}
for effect in effects.values():
    for shadow in effect['effects']:
        assert not shadow.pop('boundVariables', None)
data = dict(family=slug, sourceFileKey=identity['fileKey'], sourcePageId=identity['pageId'],
            sourceSetId=identity['setId'], sourceNorm=str(norm.relative_to(root)), sourceNormSha256=digest(norm),
            sourceParts={str(path.relative_to(root)):digest(path) for path in parts}, properties=identity['properties'],
            variants=variants, styles=styles, tokens=tokens)
if effects:
    data['effectStyles'] = effects
path = root / f'specs/data/{slug}.v1.0.0.json'
path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
print(digest(path))
