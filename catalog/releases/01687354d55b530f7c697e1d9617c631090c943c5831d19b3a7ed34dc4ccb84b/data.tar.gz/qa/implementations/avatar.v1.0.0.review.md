# QA de implementación · Avatar y Avatar group

2026-11-11 · AVATAR-001 y AVATAR-GROUP-001. Avatar group PASS. Avatar Figma BLOCKED para los cuatro fills de imagen. Avatar web PASS.

## Figma

Avatar `145:106` → `83:18`. La lectura independiente comprueba las cuatro variantes de [icono](../../implementations/figma/root-families-2026-11-11/avatar-4.readback.json) y las cuatro de [texto](../../implementations/figma/root-families-2026-11-11/avatar-8.readback.json) sin diferencias. La [lectura de imagen](../../implementations/figma/root-families-2026-11-11/avatar-0.readback.json) encuentra cuatro diferencias, todas en el fill de imagen. La estructura y las demás propiedades de esas variantes coinciden.

Los fills de destino son `83:7`, `83:10`, `83:13` y `83:16`. Figma no contiene la imagen con hash `33f6b019db4382817513e4485e94d3a7dd5a6ca2` en el destino. La [procedencia local](../../specs/data/avatar.assets.v1.0.0.json) conserva hash, dimensiones y origen. El primer intento de transporte no resolvió el host en el sandbox. La revisión automática rechazó escalar la transferencia de la fotografía al endpoint de Figma y exige autorización explícita para ese archivo y destino. No se transfirió la imagen. Reanudar solo cuando se obtenga esa autorización y verificar los cuatro fills y su transformación con una nueva lectura.

Avatar group `145:147` → `85:10`. [Lectura independiente](../../implementations/figma/root-families-2026-11-11/avatar-group-0.readback.json) sin diferencias en cuatro variantes y 116 comprobaciones de bindings. El Slot Avatars `Avatars#85:0` restringe la preferencia al set Avatar y conserva mínimo 2 y máximo 4. La muestra usa Avatar de texto. La [prueba nativa desde instancias](../../implementations/figma/root-families-2026-11-11/avatar-consumer.readback.json) pasó 19 comprobaciones de iniciales con acento, visibilidad de Status, swap Phosphor, orden, vínculos, cardinalidad y limpieza de instancias temporales. Esta prueba usa Avatar de texto e icono.

## Web

TypeScript, 9 pruebas Node y el build de Next pasaron. [Chrome en localhost](../../implementations/web/tests/buttons-loader.browser.mjs) verificó la decodificación de la fotografía original de 800 px, Avatar de 48 px con nombre accesible y estado, cuatro elementos visibles para siete participantes y contador +4 con texto accesible. El servidor de prueba bloqueó solicitudes externas. La sustitución de una imagen fallida por iniciales o glyph forma parte del código.
