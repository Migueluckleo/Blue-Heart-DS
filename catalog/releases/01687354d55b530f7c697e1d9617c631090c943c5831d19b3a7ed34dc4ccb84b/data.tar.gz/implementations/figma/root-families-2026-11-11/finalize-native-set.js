if (figma.fileKey !== DATA.fileKey) throw Error('Unexpected destination');
const set = await figma.getNodeByIdAsync(DATA.setId);
const page = set?.parent;
if (page?.id !== DATA.pageId || set.name !== DATA.setName) throw Error('Unexpected set');
await figma.setCurrentPageAsync(page);
set.documentationLinks = DATA.links;
for (const [id,reactions] of Object.entries(DATA.reactions)) {
  const variant = await figma.getNodeByIdAsync(id);
  let parent = variant;
  while (parent && parent.id !== set.id) parent = parent.parent;
  if (!parent) throw Error('Wrong owner '+id);
  await variant.setReactionsAsync(reactions);
}
return {setId:set.id,documentationLinks:set.documentationLinks,reactions:Object.keys(DATA.reactions),mutatedNodeIds:[set.id,...Object.keys(DATA.reactions)]};
