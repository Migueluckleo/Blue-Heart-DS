'use client';
import * as Examples from '../examples';
import type { ComponentType } from 'react';
export const examples: Record<string, ComponentType> = {
  "breadcrumb": Examples.BreadcrumbExample,
  "breadcrumb-item": Examples.BreadcrumbItemExample,
  "buttons": Examples.ButtonsExample,
  "checkbox": Examples.CheckboxExample,
  "dot": Examples.DotExample,
  "file-upload": Examples.FileUploadExample,
  "icon-button": Examples.IconButtonExample,
  "linear-progress": Examples.LinearProgressExample,
  "loader": Examples.LoaderExample,
  "menu-item": Examples.MenuItemExample,
  "radio": Examples.RadioExample,
  "radio-group": Examples.RadioGroupExample,
  "search": Examples.SearchExample,
  "sidebar": Examples.SidebarExample,
  "toggle": Examples.ToggleExample,
  "tooltip": Examples.TooltipExample,
  "top-bar": Examples.TopBarExample,
};
