# Componentes web

Índice generado. Cada ficha contiene API, ejemplo ejecutable, Slots, fuentes y límites.

- [Breadcrumb](breadcrumb.md) · BREADCRUMB-001
- [Breadcrumb item](breadcrumb-item.md) · BREADCRUMB-ITEM-001
- [Buttons](buttons.md) · BUTTON-001
- [Checkbox](checkbox.md) · CHECKBOX-001
- [Dot](dot.md) · DOT-001
- [File Upload](file-upload.md) · FILE-UPLOAD-001
- [Icon Button](icon-button.md) · ICON-BUTTON-001
- [Linear Progress Bar](linear-progress.md) · LINEAR-PROGRESS-001
- [Loader](loader.md) · LOADER-001
- [Menu item](menu-item.md) · MENU-ITEM-001
- [Radio](radio.md) · RADIO-001
- [Radio group](radio-group.md) · RADIO-GROUP-001
- [Search](search.md) · SEARCH-001
- [Sidebar](sidebar.md) · SIDEBAR-001
- [Toggle](toggle.md) · TOGGLE-001
- [Tooltip](tooltip.md) · TOOLTIP-001
- [Top bar](top-bar.md) · TOP-BAR-001
