'use client';

import { CaretDownIcon } from '@phosphor-icons/react/dist/csr/CaretDown';
import { QuestionIcon } from '@phosphor-icons/react/dist/csr/Question';
import type { Icon } from '@phosphor-icons/react';
import { useId, useState, type ChangeEvent, type FocusEvent, type HTMLInputTypeAttribute } from 'react';
import { Badge } from './badge';

export type InputSize = 'large' | 'medium' | 'small';
export type InputStatus = 'default' | 'hover' | 'focus' | 'success' | 'error' | 'read-only' | 'disabled';

export interface InputProps {
  id?: string;
  name?: string;
  type?: Extract<HTMLInputTypeAttribute, 'text' | 'email' | 'search' | 'url' | 'tel' | 'password'>;
  size?: InputSize;
  status?: InputStatus;
  label: string;
  placeholder?: string;
  helperText?: string;
  value?: string;
  defaultValue?: string;
  onValueChange?: (value: string, event: ChangeEvent<HTMLInputElement>) => void;
  onBlur?: (event: FocusEvent<HTMLInputElement>) => void;
  required?: boolean;
  showLabel?: boolean;
  showPlaceholder?: boolean;
  showHelper?: boolean;
  showTooltip?: boolean;
  showIcon?: boolean;
  icon?: Icon;
  showBadge?: boolean;
  badgeLabel?: string;
  className?: string;
}

export function Input({id, name, type = 'text', size = 'large', status = 'default', label,
  placeholder, helperText, value, defaultValue = '', onValueChange, onBlur, required = true,
  showLabel = true, showPlaceholder = true, showHelper = true, showTooltip = false,
  showIcon = true, icon: Glyph = CaretDownIcon, showBadge = false, badgeLabel = 'MXN', className}: InputProps) {
  const generatedId = useId();
  const controlId = id ?? generatedId;
  const helperId = showHelper && helperText ? `${controlId}-help` : undefined;
  const [internalValue, setInternalValue] = useState(defaultValue);
  const currentValue = value ?? internalValue;

  return <div className={['bh-input',className].filter(Boolean).join(' ')} data-blueheart="input"
    data-size={size} data-status={status} data-filled={currentValue.length > 0}>
    {showLabel && <div className="bh-input-label-row">
      <label className="bh-input-label" htmlFor={controlId}>
        {label}{required && <span className="bh-input-required" aria-hidden="true">*</span>}
      </label>
      {showTooltip && <QuestionIcon className="bh-input-question" weight="light" aria-hidden="true"/>}
    </div>}
    <div>
      <div className="bh-input-field">
        <input id={controlId} name={name} type={type} className="bh-input-control" value={currentValue}
          placeholder={showPlaceholder ? placeholder : undefined} required={required} disabled={status === 'disabled'}
          readOnly={status === 'read-only'} aria-label={showLabel ? undefined : label}
          aria-invalid={status === 'error' || undefined} aria-describedby={helperId} onBlur={onBlur}
          onChange={event => {
            if (value === undefined) setInternalValue(event.currentTarget.value);
            onValueChange?.(event.currentTarget.value, event);
          }}/>
        {showBadge && <Badge type="subtle" size="small" label={badgeLabel}/>}
        {showIcon && <Glyph className="bh-input-icon" weight="light" aria-hidden="true"/>}
      </div>
      {helperId && <p className="bh-input-helper" id={helperId}>{helperText}</p>}
    </div>
  </div>;
}
