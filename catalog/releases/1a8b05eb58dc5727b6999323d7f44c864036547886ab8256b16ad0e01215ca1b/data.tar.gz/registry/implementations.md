# Implementaciones y bindings

Registro inicial vacío. Registrar alcance, fuente, versión y evidencia según [P05](../protocols/05-SELF-DOCUMENTATION-AND-TRACEABILITY.md).

## FOUNDATIONS-BLUEHEART-VARIABLES-001 v0.1.2

AI Blueheart DS · tres colecciones locales · `VALIDATED` para variables. [Mapa](../implementations/figma/variables-2026-11-11/id-map.json), [readback final](../implementations/figma/variables-2026-11-11/final-collections.readback.json) y [estado](../implementations/figma/variables-2026-11-11/blueheart-variables.v0.1.2.state.json). Escritura efectiva confirmada para variables.

## Buttons y Loader

Maestro AI Blueheart DS. [Página Buttons](https://www.figma.com/design/yZsIpXywybsPDytjolwcP4/AI-Blueheart-DS?node-id=22-3) y [página Loader](https://www.figma.com/design/yZsIpXywybsPDytjolwcP4/AI-Blueheart-DS?node-id=22-2). [IDs Buttons](../implementations/figma/buttons-loader-2026-11-11/buttons.state.json) y [IDs Loader](../implementations/figma/buttons-loader-2026-11-11/loader.state.json). El catálogo local Next.js exporta ambas familias.

## Logos · LOGOS-001

[Logos en AI Blueheart DS](https://www.figma.com/design/yZsIpXywybsPDytjolwcP4/AI-Blueheart-DS?node-id=170-2) · Figma VALIDATED_WITH_EXCEPTIONS por redondeo subpíxel documentado. Cinco sets y 68 variantes proceden de Librería v1.1.0. El set local [Beni y Navi](https://www.figma.com/design/yZsIpXywybsPDytjolwcP4/AI-Blueheart-DS?node-id=277-76) añade cuatro variantes verificadas, para un total de 6 sets y 72 variantes. [Lectura de Beni y Navi](../implementations/figma/logos-beni-navi-2026-11-13/readback.json). [Ficha, localizadores y matriz](../implementations/figma/logos-2026-11-12/README.md) · [Lectura final](../implementations/figma/logos-2026-11-12/fidelity.readback.json). Web NOT_APPLICABLE.

## Characters · CHARACTERS-001

[Página Characters](https://www.figma.com/design/yZsIpXywybsPDytjolwcP4/AI-Blueheart-DS?node-id=187-14) · BENI Standby `187:51`, NAVI Analysis `187:112`. [Mapa y lectura](../implementations/figma/characters-2026-11-12/readback.json) · [Ficha web](../implementations/web/docs/components/characters.md).

## Conversation Composer · CONVERSATION-001

[Maestro oficial 216:66](https://www.figma.com/design/yZsIpXywybsPDytjolwcP4/AI-Blueheart-DS?node-id=216-66), en la página Conversation Composer 216:109. React y ejemplo Next consumen los tokens y controles oficiales. [Lectura Figma](../implementations/figma/conversation-composer-2026-11-12/readback.json) · [Ficha técnica](../implementations/web/docs/components/conversation-composer.md) · [QA Figma y Chrome](../qa/implementations/conversation-composer.v1.0.0.review.md).

## Conversation Response · CONVERSATION-RESPONSE-001

[Set oficial 222:72](https://www.figma.com/design/yZsIpXywybsPDytjolwcP4/AI-Blueheart-DS?node-id=222-72) · página 222:309 y auxiliar Preview 222:111. La implementación web exporta la respuesta, la tarjeta y el glyph de copia para Icon Button. [Lectura de Figma](../implementations/figma/conversation-response-2026-11-12/readback.json) · [Ficha web](../implementations/web/docs/components/conversation-response.md).

## Consumo de tokens de componente · 2026-11-12

App Shell, Conversation Composer, Conversation Response y Stepper consumen los aliases de componente de la corrección. [Lectura posterior](../implementations/figma/component-token-layer-correction/readback.json) · [Mapa delegado](../specs/tokens/component-layer.correction.json).

## User message · USER-MESSAGE-001

[Maestro 237:19](https://www.figma.com/design/yZsIpXywybsPDytjolwcP4/AI-Blueheart-DS?node-id=237-19) en la página 237:20. [Lectura y QA de bindings](../implementations/figma/user-message-2026-11-13/readback.json) · [Ficha web](../implementations/web/docs/components/user-message.md).

## Chat · CHAT-001

[Set oficial 242:437](https://www.figma.com/design/yZsIpXywybsPDytjolwcP4/AI-Blueheart-DS?node-id=242-437) en la página Chat 242:658. [Lectura de los estados y Slots](../implementations/figma/chat-2026-11-13/readback.json) · [Ficha web](../implementations/web/docs/components/chat.md).

## Chat Sidebar · CHAT-SIDEBAR-001

[Set oficial 258:3326](https://www.figma.com/design/yZsIpXywybsPDytjolwcP4/AI-Blueheart-DS?node-id=258-3326) · [Lectura de Figma](../implementations/figma/chat-sidebar-2026-11-13/readback.json) · [Ficha web](../implementations/web/docs/components/chat-sidebar.md).

## Checkbox · Posición del label · 2026-11-17

[Checkbox 42:30](https://www.figma.com/design/yZsIpXywybsPDytjolwcP4/AI-Blueheart-DS?node-id=42-30) ofrece label position right/left. La [API React](../implementations/web/docs/components/checkbox.md) acepta labelPosition con default right.

## Pagination · Cantidad de registros · 2026-11-17

[Pagination 109:36](https://www.figma.com/design/yZsIpXywybsPDytjolwcP4/AI-Blueheart-DS?node-id=109-36) expone Range visible. React acepta totalRecords y pageSize para calcular el resumen. [Lectura](../implementations/figma/pagination-record-count-2026-11-17/readback.json).

## Pagination · Posición del resumen · 2026-11-17

[Pagination 109:36](https://www.figma.com/design/yZsIpXywybsPDytjolwcP4/AI-Blueheart-DS?node-id=109-36) ofrece range position left/right en Default y Compact. Web usa rangePosition, con left por defecto. [Lectura y QA](../implementations/figma/pagination-range-position-2026-11-17/readback.json).

## Table · Sticky Actions · 2026-11-17

[Table 331:2664](https://www.figma.com/design/yZsIpXywybsPDytjolwcP4/AI-Blueheart-DS?node-id=331-2664) conserva Default 142:92 y añade Sticky 331:1238. [Lectura y QA](../implementations/figma/table-sticky-actions-2026-11-17/readback.json) · [API web](../implementations/web/docs/components/table.md).

## Body · Contenido de producto · 2026-11-17

[Playground Body](https://www.figma.com/design/yZsIpXywybsPDytjolwcP4/AI-Blueheart-DS?node-id=347-2597) usa el App Shell oficial y cinco frames con controles vinculados. [Lectura](../implementations/figma/body-tokens-2026-11-17/readback.json) · [Tokens](../specs/tokens/body.v1.0.0.json).

## Política de visibilidad de tokens · 2026-11-17

[Corrección de selectores](../specs/foundations/token-visibility.contract.v1.0.0.md): Figma 1,098 scopes internos corregidos; 33 Body visibles, 1,429 internos ocultos. Web aplica la política al manifest efectivo sin cambiar CSS. Evidencia completa en [QA](../qa/implementations/token-visibility.v1.0.0.review.md). Sin publicar ni instalar.
