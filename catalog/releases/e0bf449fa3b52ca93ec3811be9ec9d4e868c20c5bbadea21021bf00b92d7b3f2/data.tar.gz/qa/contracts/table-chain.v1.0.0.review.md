# QA documental · Table y Table cell

2026-11-11 · TABLE-001 y TABLE-CELL-001 · PASS documental para el alcance delegado.

Se cotejaron los seis IDs de la raíz, 46 definiciones, Slots Rows y thumb, 42 recetas de celda y tres de scrollbar. La [lectura de Avatar](../../sources/figma-snapshots/root-families-2026-11-11/table-cell-avatar-dependency.json) identifica seis variantes afectadas. El principal usa dos en 83 instancias con foto oculta inicialmente. Cell actions, Capture y ambos scrollbars quedan habilitados para construcción nativa. Las 24 variantes de Cell sin Avatar admiten preparación por alcance parcial. El principal y las seis variantes afectadas quedan fuera del alcance de escritura nativa mientras falte el fill. La implementación web queda habilitada con Avatar y Pagination reutilizables.
