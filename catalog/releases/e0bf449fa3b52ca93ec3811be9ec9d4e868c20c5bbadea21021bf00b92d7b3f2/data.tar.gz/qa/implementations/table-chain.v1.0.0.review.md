# QA de implementación · Table y Table cell

2026-11-11 · TABLE-001 y TABLE-CELL-001 · PASS web y cuatro maestros nativos completos. Table cell conserva alcance nativo parcial. Table principal queda BLOCKED en Figma.

## Figma

La página `128:2` contiene cinco propietarios del alcance oficial. [Cell actions](../../implementations/figma/root-families-2026-11-11/table-cell-actions-0.readback.json) `826:188` → `128:191` pasó cuatro cantidades y 66 bindings. [Capture cell](../../implementations/figma/root-families-2026-11-11/table-capture-cell-0.readback.json) `826:528` → `128:228` pasó ocho variantes y 378 bindings en dos lotes. [Thumb](../../implementations/figma/root-families-2026-11-11/table-scrollbar-thumb-0.readback.json) `841:2760` → `128:261` y [Scrollbar medium](../../implementations/figma/root-families-2026-11-11/table-scrollbar-medium-0.readback.json) `827:98` → `128:264` pasaron tres definiciones, dos Slots privados y 37 bindings. Se restituyó el binding de grosor en ambos thumbs de ejemplo, `128:266` y `128:269`, y se verificó de nuevo el scrollbar.

[Table cell](../../implementations/figma/root-families-2026-11-11/table-cell-0.readback.json) `826:459` → `129:44` pasó 24 variantes, 94 nodos y 703 bindings en seis lotes. Mantiene la Description parcial y la guía `846:2773`. Los cuatro enlaces nativos conservan el estilo fuente sin decoración explícita. El navegador presenta un enlace HTML subrayado y navegable. [Lectura de rangos fuente](../../sources/figma-snapshots/root-families-2026-11-11/table-link-decoration.json)

La [prueba desde instancias](../../implementations/figma/root-families-2026-11-11/table-leaves-consumer.readback.json) pasó 30 controles. Cubre las cuatro cantidades de Cell actions y su swap, las ocho variantes Capture a 160 y 300 px con texto largo y elipsis, sustitución por un thumb vinculado de longitud 120 en cada orientación, IDs de Checkbox, Toggle, Badge y Cell actions, y limpieza de la página. La reproducción en el presentador nativo queda NOT_RUN.

## Web

TypeScript, nueve pruebas Node, build de Next y la suite integral de Chrome pasaron en el catálogo de 39 familias. Chrome confirmó encabezados y scope, selección con Checkbox, enlace y acción por teclado, cambio de Capture, desplazamiento horizontal y vertical con cabecera móvil, Pagination fuera del viewport, tamaño de página, orden, inserción, retirada y selección de filas. Link en Hover con tema Servicios midió 4.308:1, de acuerdo con la excepción de origen. La norma también registra Link Selected 4.442:1 y Capture off mínimo 4.258:1. [Pruebas de navegador](../../implementations/web/tests/buttons-loader.browser.mjs)

## Bloqueo y reanudación

[Seis variantes de Table cell](../../sources/figma-snapshots/root-families-2026-11-11/table-cell-avatar-dependency.json) contienen Avatar image/medium `145:96` → `83:12`. La revisión automática rechazó la transferencia de la foto original sin autorización explícita. El fill permanece pendiente y la transferencia no se reintentó.

Table `827:99` usa dos variantes afectadas en 83 celdas, con Show avatar=false en la muestra. El anfitrión puede activar la foto desde la instancia. Se conserva la [receta de continuidad](../../sources/figma-snapshots/root-families-2026-11-11/table-main-continuation.json) con Rows, nueve filas, 108 celdas, propiedades de texto y booleanas, y las referencias de composición. Una vez habilitado Avatar, completar las seis variantes en `129:44`, restaurar el orden y default fuente, y construir Table en `128:2`. Probar Rows desde instancias con cabecera sola y más de nueve filas, edición estructural, desborde en ambos ejes y el fit de ambos thumbs.
