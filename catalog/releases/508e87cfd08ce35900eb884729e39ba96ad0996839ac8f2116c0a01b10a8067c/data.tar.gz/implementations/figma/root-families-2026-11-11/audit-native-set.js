// DATA contains destination IDs, approved variant data and identity expectations.
if (figma.fileKey !== DATA.fileKey) throw Error('Wrong destination');
const set = await figma.getNodeByIdAsync(DATA.setId);
if (set?.type !== 'COMPONENT_SET' || set.parent?.id !== DATA.pageId) throw Error('Unexpected set');
await figma.setCurrentPageAsync(set.parent);
if (DATA.applyInstanceOverrides) figma.skipInvisibleInstanceChildren = false;
const mismatches = [];
let checkedNodes = 0;
let checkedBindings = 0;
function equal(actual, expected) {
  if (typeof expected === 'number') return typeof actual === 'number' && Math.abs(actual - expected) < .03;
  if (Array.isArray(expected)) return Array.isArray(actual) && actual.length === expected.length
    && expected.every((item, index) => equal(actual[index], item));
  if (expected && typeof expected === 'object') return actual && typeof actual === 'object'
    && Object.keys(expected).every(key => equal(actual[key], expected[key]));
  return actual === expected;
}
function check(id, key, actual, expected) {
  if (!equal(actual, expected)) mismatches.push({id,key,actual,expected});
}
async function verify(source, node) {
  const id = source.id;
  if (!node || node.id !== DATA.nodes[id]) {
    mismatches.push({id,key:'id',actual:node?.id,expected:DATA.nodes[id]});
    return;
  }
  checkedNodes++;
  for (const field of ['name','type','width','height','x','y','visible','layoutMode','layoutPositioning',
    'layoutSizingHorizontal','layoutSizingVertical','clipsContent','strokeAlign','rotation','characters',
    'constraints','minWidth','maxWidth','minHeight','maxHeight','dashPattern']) {
    if (source[field] !== undefined) check(id,field,node[field],source[field]);
  }
  if (source.textStyleId) check(id,'textStyleId',node.textStyleId,DATA.styles[source.textStyleId]);
  if (source.segments) {
    const parts = node.getStyledTextSegments(['textStyleId','boundVariables','fills']);
    const actual = parts.map(part=>({
      start:part.start,end:part.end,textStyleId:part.textStyleId,
      b:Object.fromEntries([...Object.entries(part.boundVariables).map(([field,v])=>[field,v.id]),
        ['fills',part.fills[0]?.boundVariables?.color?.id]]),
    }));
    const expected = source.segments.map(part=>({
      start:part.start,end:part.end,textStyleId:DATA.styles[part.textStyleId],
      b:Object.fromEntries(Object.entries(part.b).map(([field,key])=>[field,DATA.tokens[key].targetId])),
    }));
    check(id,'mixed text ranges',actual,expected);
  }
  if (source.effectStyleId) check(id,'effectStyleId',node.effectStyleId,DATA.effectStyleIds[source.effectStyleId]);
  if (source.vectorPaths) check(id,'vectorPaths',node.vectorPaths,source.vectorPaths);
  if (source.refs) {
    for (const [field,key] of Object.entries(source.refs)) {
      check(id,'refs '+field,node.componentPropertyReferences?.[field]?.split('#')[0],key.split('#')[0]);
    }
  }
  if (source.reactions) {
    const expected = source.reactions.map(r => ({...r,actions:r.actions.map(a => ({
      ...a,destinationId:DATA.nodes[a.destinationId]??DATA.dependencies?.[a.destinationId],
    }))}));
    check(id,'reactions',node.reactions,expected);
  }
  for (const [field,variable] of Object.entries(source.b)) {
    const bound = node.boundVariables?.[field];
    check(id,'variable '+field,Array.isArray(bound) ? bound[0]?.id : bound?.id,DATA.tokens[variable].targetId);
    checkedBindings++;
  }
  if (source.type === 'INSTANCE') {
    const main = await node.getMainComponentAsync();
    if (source.main.remote) {
      check(id,'official remote key',main?.remote && main.key,source.main.key);
      const shapes = node.findAllWithCriteria({types:['VECTOR']});
      check(id,'remote vector layers',shapes.map(shape=>shape.name),source.vectorFills.map(shape=>shape.name));
      for (const [index,vector] of source.vectorFills.entries()) {
        if (vector.b.fills) {
          check(id,'remote vector fill '+index,shapes[index]?.boundVariables.fills?.[0]?.id,DATA.tokens[vector.b.fills].targetId);
          checkedBindings++;
        }
      }
    } else {
      check(id,'main ID',main?.id,DATA.dependencies[source.main.id]);
      if (DATA.applyInstanceOverrides) {
        const properties = Object.fromEntries(Object.entries(node.componentProperties).map(([key,prop])=>[key.split('#')[0],prop]));
        for (const [key,prop] of Object.entries(source.instanceProperties)) {
          if (prop.type === 'TEXT' || prop.type === 'BOOLEAN') {
            check(id,'override '+key,properties[key.split('#')[0]]?.value,prop.value);
          }
        }
        for (const [name,visible] of source.instanceVisibility??[]) {
          check(id,'nested visibility '+name,node.children.find(child=>child.name===name)?.visible,visible);
        }
      }
    }
    return;
  }
  check(id,'children',node.children?.map(c=>c.id)??[],(source.children??[]).map(c=>DATA.nodes[c.id]));
  for (let index=0; index < (source.children??[]).length; index++) await verify(source.children[index],node.children[index]);
}
check(set.id,'pageName',set.parent.name,DATA.pageName);
check(set.id,'description',set.description,DATA.description);
check(set.id,'links',set.documentationLinks,DATA.links);
check(set.id,'variant IDs',set.children.map(n=>n.id),DATA.variantIds);
for (const [source,spec] of Object.entries(DATA.effectStyles??{})) {
  const style = await figma.getStyleByIdAsync(DATA.effectStyleIds[source]);
  check(set.id,'effect style name',style?.name,spec.name);
  check(set.id,'effect style values',style?.effects,spec.effects);
}
for (const [key,property] of Object.entries(DATA.properties)) {
  const name = key.split('#')[0];
  const definition = Object.entries(set.componentPropertyDefinitions).find(([k])=>k.split('#')[0]===name)?.[1];
  check(set.id,'property '+name,definition,property);
}
for (const source of DATA.variants) await verify(source,await figma.getNodeByIdAsync(DATA.nodes[source.id]));
return {setId:set.id,pageId:set.parent.id,checkedNodes,checkedBindings,checkedVariants:DATA.variants.length,mismatchCount:mismatches.length,mismatches:mismatches.slice(0,45)};
