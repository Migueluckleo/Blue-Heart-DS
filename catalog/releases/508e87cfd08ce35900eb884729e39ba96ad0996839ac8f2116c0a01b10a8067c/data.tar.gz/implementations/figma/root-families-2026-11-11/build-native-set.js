// DATA is the selected source capture and the verified variable map.
if (figma.fileKey !== DATA.targetFileKey) throw Error('Wrong destination');
const matches = figma.root.children.filter(p => p.name === DATA.pageName);
if (matches.length > 1 || (DATA.pageId && matches[0]?.id !== DATA.pageId)) throw Error('Page identity drift');
const page = matches[0] || figma.createPage();
page.name = DATA.pageName;
await figma.setCurrentPageAsync(page);
if (DATA.applyInstanceOverrides) figma.skipInvisibleInstanceChildren = false;
const created = matches.length ? [] : [page.id];
const key = ([id, t]) => figma.variables.getVariableByIdAsync(t.targetId).then(v => {
  if (!v || v.name !== t.name || v.resolvedType !== t.type) throw Error('Variable mismatch '+t.name);
  return [id,v];
});
const vars = Object.fromEntries(await Promise.all(Object.entries(DATA.tokens).map(key)));
const fonts = [...new Map(Object.values(DATA.styles).map(s => [s.fontName.family+'/'+s.fontName.style,s.fontName])).values()];
await Promise.all(fonts.map(({family,style}) => figma.loadFontAsync({family,style})));
const styles = {};
const existingStyles = await figma.getLocalTextStylesAsync();
const basicStyle = ['fontSize','lineHeight','letterSpacing','textDecoration','textCase','paragraphIndent','paragraphSpacing'];
for (const [id, spec] of Object.entries(DATA.styles)) {
  const matches = existingStyles.filter(s => s.name === spec.name);
  if (matches.length > 1) throw Error('Ambiguous style '+spec.name);
  const s = matches[0] || figma.createTextStyle();
  if (!matches.length) {
    created.push(s.id);
    s.name = spec.name;
    s.description = spec.description;
    s.fontName = {family:spec.fontName.family,style:spec.fontName.style};
    for (const prop of basicStyle) if (spec[prop] !== undefined) s[prop] = spec[prop];
    for (const [field,source] of Object.entries(spec.b)) s.setBoundVariable(field,vars[source]);
  }
  for (const [field, source] of Object.entries(spec.b)) {
    if (s.boundVariables[field]?.id !== vars[source].id) throw Error('Style binding drift '+spec.name+' '+field);
  }
  styles[id] = s;
}
const effectStyles = {};
if (DATA.effectStyles) {
  const localEffects = await figma.getLocalEffectStylesAsync();
  for (const [id,spec] of Object.entries(DATA.effectStyles)) {
    const matches = localEffects.filter(style => style.name === spec.name);
    if (matches.length > 1) throw Error('Ambiguous effect style '+spec.name);
    const style = matches[0] || figma.createEffectStyle();
    if (!matches.length) {
      created.push(style.id);
      style.name = spec.name;
      style.description = spec.description;
      style.effects = spec.effects;
    }
    effectStyles[id] = style.id;
  }
}
const fields = ['layoutMode','primaryAxisSizingMode','counterAxisSizingMode','primaryAxisAlignItems','counterAxisAlignItems',
  'paddingTop','paddingRight','paddingBottom','paddingLeft','itemSpacing','minWidth','maxWidth','minHeight','maxHeight',
  'strokesIncludedInLayout','clipsContent','cornerRadius','strokeWeight','strokeAlign','rotation','dashPattern'];
const textFields = ['fontSize','lineHeight','letterSpacing','textDecoration','textAlignHorizontal','textAlignVertical','textAutoResize'];
const nodes = {};
const textStyles = {};
const refs = [];
const remoteMains = new Map();
function paint(source, variable) {
  if (!variable) return source ?? [];
  if (source?.length !== 1 || source[0].type !== 'SOLID') throw Error('Expected one solid paint');
  return [figma.variables.setBoundVariableForPaint(source[0],'color',variable)];
}
async function instanceMain(spec) {
  if (!spec.main.remote) return await figma.getNodeByIdAsync(DATA.dependencies?.[spec.main.id]);
  const key = spec.main.key;
  if (!DATA.remoteKeys?.includes(key)) throw Error('Unverified remote component '+key);
  if (!remoteMains.has(key)) {
    const component = await figma.importComponentByKeyAsync(key);
    if (!component.remote || component.key !== key) throw Error('Remote identity drift '+key);
    remoteMains.set(key,component);
  }
  return remoteMains.get(key);
}
async function make(spec, parent) {
  let node;
  if (spec.type === 'INSTANCE') {
    const main = await instanceMain(spec);
    if (main?.type !== 'COMPONENT') throw Error('Missing instance dependency '+spec.main.id);
    node = main.createInstance();
  } else {
    const factory = {COMPONENT:'createComponent',TEXT:'createText',ELLIPSE:'createEllipse',VECTOR:'createVector',FRAME:'createFrame'}[spec.type];
    if (!factory) throw Error('Unsupported native node '+spec.type);
    node = figma[factory]();
  }
  created.push(node.id);
  nodes[spec.id] = node.id;
  parent.appendChild(node);
  node.name = spec.name;
  if (spec.type === 'INSTANCE') {
    if (DATA.applyInstanceOverrides && !spec.main.remote) {
      const keys = Object.fromEntries(Object.keys(node.componentProperties).map(key=>[key.split('#')[0],key]));
      const values = Object.fromEntries(Object.entries(spec.instanceProperties)
        .filter(([,prop])=>prop.type === 'BOOLEAN' || prop.type === 'TEXT')
        .map(([key,prop])=>[keys[key.split('#')[0]],prop.value]));
      if (Object.keys(values).length) node.setProperties(values);
      for (const [name,visible] of spec.instanceVisibility??[]) {
        const child = node.children.find(child=>child.name===name);
        if (child && child.visible !== visible) child.visible = visible;
      }
    }
    node.resize(spec.width,spec.height);
    node.constraints = spec.constraints;
    node.visible = spec.visible;
    if (DATA.applyInstanceOverrides) {
      node.layoutSizingHorizontal = spec.layoutSizingHorizontal;
      node.layoutSizingVertical = spec.layoutSizingVertical;
    }
    if (spec.main.remote) {
      for (const [field,source] of Object.entries(spec.b)) {
        if (field === 'fills') node.fills = paint(spec.fills,vars[source]);
        else node.setBoundVariable(field,vars[source]);
      }
    }
    if (spec.vectorFills) {
      const vectors = node.findAllWithCriteria({types:['VECTOR']});
      if (vectors.length !== spec.vectorFills.length) throw Error('Remote vector anatomy drift '+spec.id);
      for (const [index,vector] of vectors.entries()) {
        const expected = spec.vectorFills[index];
        if (vector.name !== expected.name) throw Error('Remote vector identity drift '+spec.id);
        if (expected.b.fills) vector.fills = paint(expected.fills,vars[expected.b.fills]);
      }
    }
    node.x = spec.x;
    node.y = spec.y;
    if (spec.refs) refs.push([node,spec.refs]);
    return node;
  }
  if (spec.type === 'TEXT') {
    const font = spec.fontName ?? spec.segments[0].fontName;
    node.fontName = {family:font.family,style:font.style};
    node.characters = spec.characters;
    for (const field of textFields) if (spec[field] !== undefined) node[field] = spec[field];
  }
  if (spec.type === 'VECTOR') node.vectorPaths = spec.vectorPaths;
  node.resize(spec.width,spec.height);
  if (spec.layoutPositioning === 'ABSOLUTE') node.layoutPositioning = 'ABSOLUTE';
  for (const field of fields) {
    if (field === 'strokesIncludedInLayout' && node.layoutMode === 'NONE') continue;
    if (spec[field] !== undefined && field in node) node[field] = spec[field];
  }
  node.visible = spec.visible;
  if (spec.constraints && 'constraints' in node) node.constraints = spec.constraints;
  node.fills = paint(spec.fills,vars[spec.b.fills]);
  node.strokes = paint(spec.strokes,vars[spec.b.strokes]);
  for (const child of spec.children ?? []) await make(child,node);
  for (const field of ['layoutSizingHorizontal','layoutSizingVertical']) {
    if (spec[field] !== undefined && (parent.type !== 'PAGE' || spec[field] !== 'FILL')) node[field] = spec[field];
  }
  for (const [field,source] of Object.entries(spec.b)) {
    if (field !== 'fills' && field !== 'strokes') node.setBoundVariable(field,vars[source]);
  }
  if (spec.type === 'TEXT' && spec.textStyleId) {
    const style = styles[spec.textStyleId];
    if (!style) throw Error('Missing linked text style');
    await node.setTextStyleIdAsync(style.id);
    textStyles[spec.id] = style.id;
  }
  for (const range of spec.segments??[]) {
    for (const [field,source] of Object.entries(range.b)) {
      if (field === 'fills') node.setRangeFills(range.start,range.end,paint(range.fills,vars[source]));
      else node.setRangeBoundVariable(range.start,range.end,field,vars[source]);
    }
    await node.setRangeTextStyleIdAsync(range.start,range.end,styles[range.textStyleId].id);
  }
  if (spec.effectStyleId) await node.setEffectStyleIdAsync(effectStyles[spec.effectStyleId]);
  node.x = spec.x;
  node.y = spec.y;
  if (spec.refs) refs.push([node,spec.refs]);
  return node;
}
const existing = page.children.find(n => n.name === DATA.setName);
if (page.children.some(n => n.id !== existing?.id && !DATA.allowedSiblingIds?.includes(n.id)) ||
    (DATA.setId && existing?.id !== DATA.setId)) throw Error('Unexpected family member');
if (existing?.children.some(c => DATA.variants.some(v => v.name === c.name))) throw Error('Variant already exists; inspect');
const mains = [];
for (const v of DATA.variants) mains.push(await make(v,page));
const set = existing || figma.combineAsVariants(mains,page);
if (existing) for (const main of mains) set.appendChild(main);
else created.push(set.id);
set.name = DATA.setName;
set.description = DATA.description;
set.fills = [];
const properties = {};
for (const [source, prop] of Object.entries(DATA.properties)) {
  if (prop.type === 'VARIANT') continue;
  const name = source.split('#')[0];
  const key = Object.keys(set.componentPropertyDefinitions).find(k => k.startsWith(name+'#'));
  properties[source] = key || set.addComponentProperty(name,prop.type,prop.defaultValue);
}
for (const [node,map] of refs) node.componentPropertyReferences = Object.fromEntries(
  Object.entries(map).map(([field,source]) => {
    if (!properties[source]) throw Error('Unresolved component property '+source);
    return [field,properties[source]];
  }),
);
for (let i=0;i<mains.length;i++) {
  mains[i].x = DATA.variants[i].x;
  mains[i].y = DATA.variants[i].y;
}
set.resize(Math.max(...set.children.map(n=>n.x+n.width))+24,Math.max(...set.children.map(n=>n.y+n.height))+24);
if (DATA.setGeometry) {
  set.resize(DATA.setGeometry.width,DATA.setGeometry.height);
  set.x = DATA.setGeometry.x;
  set.y = DATA.setGeometry.y;
}
return {fileKey:figma.fileKey,pageId:page.id,setId:set.id,createdNodeIds:created,mutatedNodeIds:[page.id,set.id],nodes,textStyles,
  styles:Object.fromEntries(Object.entries(styles).map(([source,s])=>[source,s.id])),effectStyles,
  variants:mains.map(n=>({id:n.id,name:n.name})),properties:set.componentPropertyDefinitions};
