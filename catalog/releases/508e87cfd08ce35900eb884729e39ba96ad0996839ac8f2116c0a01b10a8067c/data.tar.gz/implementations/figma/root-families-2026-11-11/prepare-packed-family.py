"""Prepare bounded native mutations and independent reads from the delegated family."""
import json
import sys
from pathlib import Path

here = Path(__file__).resolve().parent
root = here.parents[2]
part, operation, start, limit = sys.argv[1:]
start, limit = int(start), int(limit)
linked = part in ('file-upload','checkbox')
slug = part if linked else 'linear-progress'
spec = json.loads((root / f'specs/data/{slug}.v1.0.0.json').read_text())
contract = (root / f'specs/components/{slug}.contract.v1.0.0.md').read_text()
receipts = [json.loads(path.read_text()) for path in here.glob(f'{slug}-*.mutation.json')]
set_name = {'file-upload':'File Upload','checkbox':'Checkbox','helper':'__Linear Progress/Indeterminate'}.get(part,f'Linear Progress Bar/{part}')
family_set = next(item for item in spec['sets'] if item['name'] == set_name)
target_key = 'yZsIpXywybsPDytjolwcP4'
ids = {entry['setName']: entry['setId'] for entry in receipts}
nodes = {src: dst for entry in receipts for src, dst in entry['nodes'].items()}
styles = {src: dst for entry in receipts for src, dst in entry['styles'].items()}
description_section = contract.split('## Description exacta')[1].split('##')[0].strip()
description = description_section if linked else next(
    row.split(' | ')[1] for row in description_section.splitlines() if row.startswith(f'| {set_name} |')
).removesuffix(' |')
guide = {'file-upload':'477-12','checkbox':'382-12'}.get(part,'448-14')
links = [{'uri': f"https://www.figma.com/design/{spec['sourceFileKey']}?node-id={guide}"}]
data = dict(targetFileKey=target_key, fileKey=target_key, pageName=set_name if linked else 'Linear Progress Bar',
            pageId=receipts[0]['pageId'] if receipts else None, setName=set_name, setId=ids.get(set_name),
            allowedSiblingIds=list(ids.values()), description=description, links=links, tokens=spec['tokens'],
            styles=spec['styles'] if operation == 'build' else styles, properties=family_set['props'],
            setGeometry={key: family_set[key] for key in ('x', 'y', 'width', 'height')}, dependencies=dict(nodes))

if linked:
    evidence = root / 'sources/figma-snapshots/root-families-2026-11-11/phosphor-file-upload-checkbox.json'
    library = json.loads(evidence.read_text())
    assert library['fileKey'] == 'xZSksKpcQTp5H3C4dZApBL'
    data['remoteKeys'] = [key for icon in library['sets'] for _,key in icon['variants']]
    data['applyInstanceOverrides'] = True
    if part == 'file-upload':
        button = here.parent / 'buttons-loader-2026-11-11/button-secondary.mutation.json'
        button_variants = json.loads(button.read_text())['sets'][0]['variants']
        data['dependencies'].update({v['sourceId']:v['id'] for v in button_variants})
        for path in here.glob('linear-progress-large-*.mutation.json'):
            data['dependencies'].update(json.loads(path.read_text())['nodes'])

if operation == 'finalize':
    data['reactions'] = {}
    for source in family_set['variants']:
        if source['reactions']:
            data['reactions'][nodes[source['id']]] = [
                {**reaction, 'actions': [{**a, 'destinationId': nodes[a['destinationId']]} for a in reaction['actions']]}
                for reaction in source['reactions']
            ]
    program = (here / 'finalize-native-set.js').read_text()
else:
    fields, pool, indexes = [], [], {}
    def pack(node):
        pairs = []
        for key, value in node.items():
            if key not in fields:
                fields.append(key)
            if key == 'children':
                encoded = [pack(child) for child in value]
            else:
                signature = json.dumps(value, separators=(',', ':'), ensure_ascii=False)
                if signature not in indexes:
                    indexes[signature] = len(pool)
                    pool.append(value)
                encoded = indexes[signature]
            pairs.extend((fields.index(key), encoded))
        return pairs

    data['packed'] = [pack(variant) for variant in family_set['variants'][start:start + limit]]
    data.update(fields=fields, pool=pool)
    if operation == 'audit':
        data.update(nodes=nodes, variantIds=[nodes[v['id']] for v in family_set['variants']])
    program = (here / ('build-native-set.js' if operation == 'build' else 'audit-native-set.js')).read_text()
    program = """function unpack(row) {
  const node = {};
  for (let i=0;i<row.length;i+=2) {
    const key=DATA.fields[row[i]], value=row[i+1];
    node[key]=key==='children'?value.map(unpack):DATA.pool[value];
  }
  return node;
}
DATA.variants=DATA.packed.map(unpack);
""" + program

print('const DATA = ' + json.dumps(data, ensure_ascii=False, separators=(',', ':')) + ';')
print(program)
