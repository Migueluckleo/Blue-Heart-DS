'use client';
import * as Examples from '../examples';
import type { ComponentType } from 'react';
export const examples: Record<string, ComponentType> = {
  "buttons": Examples.ButtonsExample,
  "dot": Examples.DotExample,
  "loader": Examples.LoaderExample,
  "radio": Examples.RadioExample,
  "radio-group": Examples.RadioGroupExample,
  "toggle": Examples.ToggleExample,
};
